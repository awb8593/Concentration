module Concentration {
    requires transitive javafx.controls;
    exports gui;
}
